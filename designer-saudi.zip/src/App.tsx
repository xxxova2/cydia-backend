import { useState } from "react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Services from "./components/Services";
import Portfolio from "./components/Portfolio";
import ContactForm from "./components/ContactForm";
import AdminDashboard from "./components/AdminDashboard";
import Footer from "./components/Footer";
import { Proposal } from "./types";
import { Sparkles, MessageSquare, ArrowRight, ArrowLeft } from "lucide-react";

export default function App() {
  const [activeSection, setActiveSection] = useState("home");
  const [showAdmin, setShowAdmin] = useState(false);

  // Pre-filled form data holding contact variables
  const [formPreFill, setFormPreFill] = useState({
    businessType: "",
    brandName: "",
    targetStyle: "",
    notes: "",
  });

  const handleNavigate = (sectionId: string) => {
    setShowAdmin(false);
    setActiveSection(sectionId);

    if (sectionId === "home") {
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }

    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const handleToggleAdmin = () => {
    setShowAdmin(!showAdmin);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-background-dark text-on-surface font-sans antialiased selection:bg-primary/20 selection:text-primary">
      {/* Main Navigation Header */}
      <Header
        onNavigate={handleNavigate}
        activeSection={activeSection}
        onToggleAdmin={handleToggleAdmin}
        showAdmin={showAdmin}
      />

      <main className="min-h-[80vh]">
        {showAdmin ? (
          <div className="pt-20">
            {/* Back button above dashboard */}
            <div className="max-w-7xl mx-auto px-4 md:px-8 pt-8 text-right">
              <button
                onClick={() => setShowAdmin(false)}
                className="inline-flex items-center gap-2 text-xs text-primary-muted hover:text-primary transition-colors font-semibold"
              >
                <span>العودة للموقع الرئيسي</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
            <AdminDashboard />
          </div>
        ) : (
          <>
            {/* Hero Splash section */}
            <Hero onNavigate={handleNavigate} />

            {/* Services catalog */}
            <Services />

            {/* Work Portfolio Gallery */}
            <Portfolio />

            {/* Onboarding acquisition lead form */}
            <ContactForm
              formData={formPreFill}
              onClearForm={() => setFormPreFill({ businessType: "", brandName: "", targetStyle: "", notes: "" })}
            />
          </>
        )}
      </main>

      {/* Copyright Footer */}
      <Footer />
    </div>
  );
}
