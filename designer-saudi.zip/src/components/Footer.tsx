export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="w-full py-12 bg-background-dark border-t border-white/5 text-right">
      <div className="flex flex-col md:flex-row-reverse justify-between items-center px-4 md:px-8 max-w-7xl mx-auto gap-6 text-sm">
        {/* Logo/Brand */}
        <div className="font-bold text-lg text-primary tracking-tight font-sans">
          DESIGNER SAUDI
        </div>

        {/* Legal Links */}
        <div className="flex gap-6 flex-wrap justify-center flex-row-reverse">
          <a href="#" className="text-on-surface-variant hover:text-primary transition-colors duration-200">
            سياسة الخصوصية
          </a>
          <a href="#" className="text-on-surface-variant hover:text-primary transition-colors duration-200">
            الشروط والأحكام
          </a>
          <a href="#" className="text-on-surface-variant hover:text-primary transition-colors duration-200">
            خريطة الموقع
          </a>
        </div>

        {/* Copyright notice */}
        <div className="text-on-surface-variant/70 font-sans">
          &copy; {currentYear} جميع الحقوق محفوظة للمصمم السعودي. تم التطوير بأعلى مستويات الاحترافية.
        </div>
      </div>
    </footer>
  );
}
