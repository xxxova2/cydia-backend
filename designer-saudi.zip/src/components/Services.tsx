import { motion } from "motion/react";
import { Layout, Code, Smartphone, Search, Award, Store } from "lucide-react";

export default function Services() {
  const servicesList = [
    {
      icon: Layout,
      title: "تصميم واجهات المستخدم (UI/UX)",
      description: "تصميم واجهات عصرية ومريحة للعين، تركز بالكامل على تجربة العميل لزيادة نسبة الشراء ومعدلات التحويل بالمبيعات.",
    },
    {
      icon: Code,
      title: "تطوير الويب والمتاجر الاحترافية",
      description: "برمجة سريعة وآمنة لمتاجر سلة، زد، وووكومرس، وشوبيفاي مع ربط بوابات الدفع (مدى، فيزا) ومزودي الشحن والتوصيل.",
    },
    {
      icon: Smartphone,
      title: "تطبيقات الجوال الفخمة",
      description: "تصميم وتطوير تطبيقات متكاملة واحترافية للآيفون والأندرويد تعكس تفرد علامتك التجارية وتسهل وصول العملاء لمنتجاتك.",
    },
    {
      icon: Search,
      title: "تحسين محركات البحث السيو (SEO)",
      description: "تهيئة متجرك أو موقعك للظهور في النتائج الأولى بمحرك بحث جوجل لجذب الزوار العضويين والمبيعات بشكل مستدام ومجاني.",
    },
  ];

  return (
    <section id="services" className="py-24 px-4 md:px-8 bg-surface-dim relative overflow-hidden">
      {/* Decorative gradient blur */}
      <div className="absolute top-1/2 left-1/4 w-72 h-72 bg-primary/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-16 space-y-4">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold text-on-surface"
          >
            خدمات متكاملة لنجاحك الرقمي في الخليج
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-on-surface-variant max-w-2xl mx-auto leading-relaxed"
          >
            أقدم مجموعة شاملة ومدروسة من الخدمات لتأسيس وإطلاق متجرك أو تطبيقك بأعلى معايير الجودة العالمية وبلمسة فخامة تناسب السوق السعودي وتطلعاته.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {servicesList.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.08 }}
                whileHover={{ y: -8 }}
                className="glass-panel p-8 rounded-2xl hover:bg-white/[0.04] transition-all duration-300 group flex flex-col text-right border border-primary-muted/10 hover:border-primary/40 relative overflow-hidden"
              >
                {/* Background absolute accent */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-primary/5 rounded-bl-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                <div className="w-14 h-14 rounded-xl bg-primary-muted/10 flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform duration-300 group-hover:bg-primary/20">
                  <IconComponent className="w-7 h-7" />
                </div>

                <h3 className="text-xl font-bold mb-3 text-on-surface group-hover:text-primary transition-colors duration-300">
                  {service.title}
                </h3>

                <p className="text-sm text-on-surface-variant leading-relaxed">
                  {service.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
