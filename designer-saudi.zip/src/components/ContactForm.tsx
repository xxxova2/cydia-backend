import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Send, CheckCircle, AlertCircle, Phone, Mail, User, Landmark, HelpCircle, Sparkles } from "lucide-react";
import { Proposal } from "../types";

interface ContactFormProps {
  formData: {
    businessType: string;
    brandName: string;
    targetStyle: string;
    notes: string;
  };
  onClearForm: () => void;
}

export default function ContactForm({ formData, onClearForm }: ContactFormProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [businessType, setBusinessType] = useState("");
  const [brandName, setBrandName] = useState("");
  const [targetStyle, setTargetStyle] = useState("فخم كلاسيكي");
  const [budget, setBudget] = useState("٢,٥٠٠ - ٥,٠٠٠ ر.س");
  const [notes, setNotes] = useState("");

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sync with prop when AI consultation proposal is forwarded
  useEffect(() => {
    if (formData.businessType) setBusinessType(formData.businessType);
    if (formData.brandName) setBrandName(formData.brandName);
    if (formData.targetStyle) setTargetStyle(formData.targetStyle);
    if (formData.notes) setNotes(formData.notes);
  }, [formData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !phone.trim()) {
      setErrorMessage("الرجاء تعبئة جميع الحقول الأساسية: الاسم، الجوال، والبريد الإلكتروني");
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const response = await fetch("/api/inquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          email,
          phone,
          businessType,
          brandName,
          targetStyle,
          budget,
          notes,
        }),
      });

      if (!response.ok) {
        throw new Error("فشل إرسال طلب الاستشارة حالياً. يرجى مراجعة الخادم.");
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setSubmitSuccess(true);
      // Clear fields
      setName("");
      setEmail("");
      setPhone("");
      setBusinessType("");
      setBrandName("");
      setNotes("");
      onClearForm();
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || "حدث خطأ غير متوقع أثناء إرسال طلبك. يرجى إعادة المحاولة.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-24 px-4 md:px-8 bg-surface-dim relative">
      <div className="absolute inset-0 z-0 opacity-10 pointer-events-none bg-[radial-gradient(ellipse_at_bottom_right,rgba(242,202,80,0.1),transparent_50%)]" />

      <div className="max-w-4xl mx-auto relative z-10">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-3xl md:text-4xl font-bold text-on-surface">
            ابدأ رحلة تأسيس متجرك الفاخر اليوم
          </h2>
          <p className="text-on-surface-variant max-w-xl mx-auto leading-relaxed">
            سجل بياناتك ومواصفات متجرك للحصول على جلسة استشارية ونموذج تصميم مبدئي مجاني لمتجرك خلال ٢٤ ساعة فقط.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
          {/* Info Side Column */}
          <div className="md:col-span-2 space-y-6 text-right">
            <div className="glass-panel p-6 rounded-2xl border border-white/5 space-y-6">
              <h3 className="text-lg font-bold text-primary border-b border-white/5 pb-3">
                لماذا DESIGNER SAUDI؟
              </h3>

              <div className="space-y-4 text-sm text-on-surface-variant leading-relaxed">
                <div className="space-y-1">
                  <h4 className="font-bold text-on-surface">⚡ جودة وسرعة استثنائية</h4>
                  <p>تجهيز وتعديل وتطوير وإطلاق المتجر بالكامل خلال ٣ أيام بأفضل تجربة مستخدم ممكنة.</p>
                </div>

                <div className="space-y-1">
                  <h4 className="font-bold text-on-surface">🇸🇦 تخصص في السوق السعودي</h4>
                  <p>ربط تام لمنافذ الدفع الشهيرة (مدى، تمارا، تابي) وتوصيل أوتوماتيكي مع سمسا وأرامكس وجي ال تي.</p>
                </div>

                <div className="space-y-1">
                  <h4 className="font-bold text-on-surface">💎 تصميم فاخر ومخصص</h4>
                  <p>نهتم بالتفاصيل الدقيقة والخطوط العربية المنسقة والألوان لتقديم مظهر ريادي لعلامتك التجارية.</p>
                </div>
              </div>
            </div>

            {/* Direct Contact */}
            <div className="glass-panel p-6 rounded-2xl border border-white/5 space-y-3">
              <h4 className="text-xs font-bold text-primary-muted">تواصل مباشر متاح</h4>
              <p className="text-xs text-on-surface-variant leading-relaxed">
                يسعدنا الرد على استفساراتكم مباشرة عبر البريد الإلكتروني أو الواتساب في أي وقت.
              </p>
              <div className="pt-2 text-xs text-on-surface space-y-1 font-mono">
                <p>📧 design@saudi.com</p>
                <p>📱 +966 50 123 4567</p>
              </div>
            </div>
          </div>

          {/* Form Side Column */}
          <div className="md:col-span-3">
            {submitSuccess ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="glass-panel p-8 rounded-2xl border border-green-500/20 text-center space-y-4"
              >
                <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center text-green-400 mx-auto">
                  <CheckCircle className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-bold text-on-surface">تم استلام طلبك بنجاح!</h3>
                <p className="text-sm text-on-surface-variant leading-relaxed">
                  شكراً لثقتك بـ <strong>DESIGNER SAUDI</strong>. لقد تم تسجيل تفاصيل الخطة في نظامنا بنجاح، ويقوم المصمم السعودي حالياً بمراجعة أفكارك وسنتصل بك على رقم الجوال المسجل خلال ساعة واحدة لتأكيد موعد استشارتك المجانية.
                </p>
                <button
                  onClick={() => setSubmitSuccess(false)}
                  className="bg-primary hover:bg-[#ffe088] text-[#1a1500] px-6 py-2 rounded-xl text-xs font-bold transition-colors"
                >
                  إرسال طلب آخر
                </button>
              </motion.div>
            ) : (
              <div className="glass-panel p-6 md:p-8 rounded-2xl border border-primary/10">
                <form onSubmit={handleSubmit} className="space-y-4 text-right">
                  {/* Basic fields */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-on-surface-variant">الاسم الكامل <span className="text-primary">*</span></label>
                    <div className="relative">
                      <User className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-on-surface-variant/40" />
                      <input
                        type="text"
                        placeholder="مثال: محمد بن علي بن أحمد"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full bg-background-dark/80 border border-white/5 rounded-xl pr-10 pl-4 py-3 text-sm text-on-surface focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary text-right"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-on-surface-variant">رقم الجوال السعودي <span className="text-primary">*</span></label>
                      <div className="relative">
                        <Phone className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-on-surface-variant/40" />
                        <input
                          type="tel"
                          placeholder="05xxxxxxxx"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          className="w-full bg-background-dark/80 border border-white/5 rounded-xl pr-10 pl-4 py-3 text-sm text-on-surface focus:border-primary focus:outline-none text-right font-mono"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-on-surface-variant">البريد الإلكتروني <span className="text-primary">*</span></label>
                      <div className="relative">
                        <Mail className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-on-surface-variant/40" />
                        <input
                          type="email"
                          placeholder="client@example.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full bg-background-dark/80 border border-white/5 rounded-xl pr-10 pl-4 py-3 text-sm text-on-surface focus:border-primary focus:outline-none text-right font-mono"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {/* Pre-filled / AI details if routed */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-on-surface-variant">فئة النشاط أو المتجر</label>
                      <input
                        type="text"
                        placeholder="مثال: العبايات الفاخرة، العطور..."
                        value={businessType}
                        onChange={(e) => setBusinessType(e.target.value)}
                        className="w-full bg-background-dark/80 border border-white/5 rounded-xl px-4 py-3 text-sm text-on-surface focus:border-primary focus:outline-none text-right"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-on-surface-variant">اسم البريد / الماركة</label>
                      <input
                        type="text"
                        placeholder="اختياري"
                        value={brandName}
                        onChange={(e) => setBrandName(e.target.value)}
                        className="w-full bg-background-dark/80 border border-white/5 rounded-xl px-4 py-3 text-sm text-on-surface focus:border-primary focus:outline-none text-right"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-on-surface-variant">الميزانية التقديرية المرصودة</label>
                      <select
                        value={budget}
                        onChange={(e) => setBudget(e.target.value)}
                        className="w-full bg-background-dark border border-white/5 rounded-xl px-4 py-3 text-sm text-on-surface focus:border-primary focus:outline-none text-right"
                      >
                        <option value="٢,٥٠٠ - ٥,٠٠٠ ر.س">٢,٥٠٠ - ٥,٠٠٠ ريال سعودي (سلة/زد)</option>
                        <option value="٥,٠٠٠ - ١٠,٠٠٠ ر.س">٥,٠٠٠ - ١٠,٠٠٠ ريال سعودي (براند متكامل)</option>
                        <option value="أكثر من ١٠,٠٠٠ ر.س">أكثر من ١٠,٠٠٠ ريال سعودي (برمجة كود خاص)</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-on-surface-variant">الأسلوب البصري المفضل</label>
                      <input
                        type="text"
                        placeholder="مثال: فخم، كلاسيكي، بسيط..."
                        value={targetStyle}
                        onChange={(e) => setTargetStyle(e.target.value)}
                        className="w-full bg-background-dark/80 border border-white/5 rounded-xl px-4 py-3 text-sm text-on-surface focus:border-primary focus:outline-none text-right"
                      />
                    </div>
                  </div>

                  {/* Notes / AI proposal content */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-on-surface-variant">تفاصيل إضافية أو متطلبات الربط</label>
                    <textarea
                      rows={3}
                      placeholder="صف أي تفاصيل إضافية أو الصق مخرجات التخطيط بالذكاء الاصطناعي هنا لتسهيل النقاش مع المصمم..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="w-full bg-background-dark/80 border border-white/5 rounded-xl px-4 py-3 text-sm text-on-surface focus:border-primary focus:outline-none text-right resize-none"
                    />
                  </div>

                  {errorMessage && (
                    <div className="flex items-center gap-2 justify-end text-red-400 text-xs mt-2 font-semibold">
                      <span>{errorMessage}</span>
                      <AlertCircle className="w-3.5 h-3.5" />
                    </div>
                  )}

                  {/* Action button */}
                  <div className="pt-2 flex justify-end">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-gold-gradient hover:bg-gold-gradient-hover text-[#1a1500] px-8 py-3.5 rounded-xl font-bold transition-all duration-300 shadow-xl bg-glow-gold disabled:opacity-50"
                    >
                      {isSubmitting ? "جاري الإرسال..." : "إرسال الطلب وحجز استشارة"}
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
