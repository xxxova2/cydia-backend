import { useState } from "react";
import { Menu, X, Settings, Sparkles } from "lucide-react";

interface HeaderProps {
  onNavigate: (section: string) => void;
  activeSection: string;
  onToggleAdmin: () => void;
  showAdmin: boolean;
}

export default function Header({ onNavigate, activeSection, onToggleAdmin, showAdmin }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false);

  const navItems: { id: string; label: string; badge?: string }[] = [
    { id: "services", label: "الخدمات" },
    { id: "contact", label: "طلب استشارة" },
  ];

  const handleItemClick = (id: string) => {
    onNavigate(id);
    setIsOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-[#16130b]/80 backdrop-blur-xl border-b border-white/5 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 md:px-8 h-20 flex justify-between items-center">
        {/* Brand */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => onNavigate("home")}
            className="font-bold text-xl md:text-2xl text-primary tracking-tight hover:opacity-90 transition-opacity text-right font-sans"
          >
            DESIGNER SAUDI
          </button>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex gap-8 items-center">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleItemClick(item.id)}
              className={`relative py-2 text-sm font-medium transition-colors hover:text-primary ${
                activeSection === item.id ? "text-primary" : "text-on-surface-variant"
              }`}
            >
              {item.label}
              {item.badge && (
                <span className="absolute -top-1 -right-8 bg-primary/20 text-primary text-[10px] px-1.5 py-0.5 rounded-full font-bold animate-pulse">
                  {item.badge}
                </span>
              )}
              {activeSection === item.id && (
                <span className="absolute bottom-0 left-0 w-full h-[2px] bg-primary rounded-full" />
              )}
            </button>
          ))}
        </nav>

        {/* Trailing Actions */}
        <div className="hidden md:flex items-center gap-4">
          <button
            onClick={onToggleAdmin}
            className={`flex items-center gap-2 text-xs font-semibold px-4 py-2 rounded-lg border transition-all duration-200 ${
              showAdmin
                ? "bg-primary text-[#1a1500] border-primary"
                : "bg-white/5 text-on-surface hover:bg-white/10 border-white/10"
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>لوحة التحكم</span>
          </button>

          <button
            onClick={() => onNavigate("contact")}
            className="inline-flex items-center justify-center bg-gold-gradient text-[#1a1500] text-sm px-6 py-2.5 rounded-full hover:bg-gold-gradient-hover transition-all duration-300 bg-glow-gold font-semibold shadow-lg"
          >
            تواصل معي
          </button>
        </div>

        {/* Mobile Menu Actions */}
        <div className="flex md:hidden items-center gap-2">
          <button
            onClick={onToggleAdmin}
            className={`p-2 rounded-lg border transition-all duration-200 ${
              showAdmin
                ? "bg-primary text-[#1a1500] border-primary"
                : "bg-white/5 text-on-surface border-white/10"
            }`}
            title="لوحة التحكم"
          >
            <Settings className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="text-primary p-2 focus:outline-none"
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isOpen && (
        <div className="md:hidden absolute top-20 left-0 w-full bg-[#16130b] border-b border-white/5 py-6 px-6 shadow-2xl space-y-4">
          <div className="flex flex-col gap-4">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleItemClick(item.id)}
                className={`text-right py-2.5 text-base font-medium border-b border-white/5 flex justify-between items-center ${
                  activeSection === item.id ? "text-primary font-bold" : "text-on-surface-variant"
                }`}
              >
                <span>{item.label}</span>
                {item.badge && (
                  <span className="bg-primary/20 text-primary text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                    {item.badge}
                  </span>
                )}
              </button>
            ))}

            <button
              onClick={() => {
                onNavigate("contact");
                setIsOpen(false);
              }}
              className="w-full text-center bg-gold-gradient text-[#1a1500] py-3 rounded-full hover:bg-gold-gradient-hover transition-all duration-300 bg-glow-gold font-bold"
            >
              تواصل معي
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
