import { motion } from "motion/react";
import { Sparkles, ArrowLeft, Rocket, CheckCircle } from "lucide-react";

interface HeroProps {
  onNavigate: (section: string) => void;
}

export default function Hero({ onNavigate }: HeroProps) {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center pt-28 pb-16 px-4 md:px-8 overflow-hidden">
      {/* Background Decorative Mesh & Glow */}
      <div className="absolute inset-0 z-0 opacity-20 pointer-events-none bg-[radial-gradient(ellipse_at_top_right,rgba(242,202,80,0.15),transparent_50%),radial-gradient(ellipse_at_bottom_left,rgba(35,31,23,0.3),transparent_60%)]" />
      
      {/* Abstract Tech Background lines */}
      <div 
        className="absolute inset-0 z-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle_at_center, #eae1d4 1px, transparent 1px)`,
          backgroundSize: "24px 24px"
        }}
      />

      <div className="relative z-10 max-w-7xl w-full mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Right content column (RTL First) */}
        <motion.div 
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-right space-y-8 order-2 lg:order-1"
        >
          <span className="inline-flex items-center gap-2 glass-panel px-4 py-1.5 rounded-full text-primary border border-primary/20 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 animate-pulse" />
            <span>مصمم ومطور سعودي محترف لمتاجر النخبة</span>
          </span>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-on-surface">
            أصمم متجرك الإلكتروني الفاخر في <span className="text-gradient-gold">٣ أيام فقط</span>
          </h1>

          <p className="text-lg text-on-surface-variant max-w-xl leading-relaxed">
            حلول رقمية متكاملة تجمع بين الفخامة والأداء العالي. متخصص في تأسيس المتاجر والمنصات وتطبيقات الجوال التي تعكس هويتك الفخمة وتضاعف نسبة مبيعاتك وأرباحك.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-start">
            <button
              onClick={() => onNavigate("contact")}
              className="inline-flex items-center justify-center gap-2 bg-gold-gradient text-[#1a1500] text-base px-10 py-4 rounded-xl hover:bg-gold-gradient-hover transition-all duration-300 bg-glow-gold font-bold shadow-lg group"
            >
              <Rocket className="w-4 h-4 transition-transform group-hover:-translate-y-1" />
              <span>تواصل معنا الآن</span>
            </button>
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-2 gap-6 pt-8 border-t border-white/5 mt-8">
            <div className="flex items-center gap-3 justify-start">
              <div className="w-12 h-12 rounded-full glass-panel flex items-center justify-center text-primary">
                <span className="text-lg font-bold">+٥٠</span>
              </div>
              <div className="text-right">
                <p className="text-sm text-on-surface-variant">مشروع ناجح ومنشور</p>
                <p className="text-xs text-primary/80 font-semibold">بأعلى تقييم رضا 100%</p>
              </div>
            </div>

            <div className="flex items-center gap-3 justify-start">
              <div className="w-12 h-12 rounded-full glass-panel flex items-center justify-center text-primary">
                <span className="text-lg font-bold">٣٦ س</span>
              </div>
              <div className="text-right">
                <p className="text-sm text-on-surface-variant">متوسط سرعة التسليم</p>
                <p className="text-xs text-primary/80 font-semibold">لأول مسودة تصميمية</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Left image column */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="order-1 lg:order-2 relative aspect-square max-w-md mx-auto w-full flex items-center justify-center"
        >
          {/* Ambient Glow behind image */}
          <div className="absolute inset-0 bg-primary/5 rounded-full blur-[80px] pointer-events-none" />

          {/* Golden background rotating card decor */}
          <div className="absolute inset-0 rounded-2xl glass-panel transform rotate-3 scale-105 opacity-40 border border-primary/10" />

          {/* Premium Mockup Image Container */}
          <div className="absolute inset-0 rounded-2xl overflow-hidden glass-panel border border-primary/30 p-2.5 shadow-2xl">
            <img 
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover rounded-xl" 
              alt="Premium 3D Saudi E-commerce smartphone and laptop mockup showing custom boutique interfaces." 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDNou5XNyvwQD8hLK5q4vzRijpXYik7Sju1oWamAodqjL7oN7oLR3-pDPchlDDOQPn7aY5vQP9CbdrhA3AX6GfWlA2ispSgme6oKnmGp0-tVJ_c72SuGhCUbdODJSkaPz7OmpFTxfpItOn_4z0wNqXHk2uoXjgHTFkQARj4u-p1u3zr3CzutJIi5dDiee725oPAwwzev6xGQXhvJdGjiJvOKlO9buY58jj7tRrw_11EYKCN5C6tYrNZK5IFMPPnCXEFPqpS5md3UFNI"
            />
          </div>

          {/* Floating Availability Badge */}
          <motion.div 
            animate={{ y: [0, -6, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -bottom-6 -left-4 glass-panel rounded-xl p-4 flex items-center gap-3 shadow-2xl bg-surface/90 border border-primary-muted/20"
          >
            <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center text-green-400">
              <CheckCircle className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <p className="text-xs font-semibold text-on-surface">متاح للعمل الفوري</p>
              <p className="text-[10px] text-green-400">رد وتواصل سريع خلال ساعة</p>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
