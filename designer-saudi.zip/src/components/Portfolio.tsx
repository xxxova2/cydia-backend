import React from "react";
import { motion } from "motion/react";
import { ExternalLink, Sparkles, Smartphone, Award, Landmark, Eye } from "lucide-react";

interface Project {
  title: string;
  category: string;
  image: string;
  description: string;
  tags: string[];
  features: string[];
}

const PROJECTS: Project[] = [
  {
    title: "مجموعة عبق العود الفاخرة",
    category: "عطور وبخور ملكي",
    image: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?q=80&w=800&auto=format&fit=crop",
    description: "تصميم متجر إلكتروني بهوية كلاسيكية مذهبة وتجربة مستخدم فاخرة لعلامة تجارية متخصصة في العود ودهن العود النادر والزيوت العطرية الراقية.",
    tags: ["تصميم هويّة", "منصة سلة", "كتابة إعلانية"],
    features: ["بوابات الدفع الفوري مدى وأبل باي", "ربط تلقائي مع سمسا للشحن اليومي", "نظام قسائم هدايا مخصص"]
  },
  {
    title: "بوتيك رداء الفخامة للعبايات",
    category: "أزياء نسائية راقية",
    image: "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=800&auto=format&fit=crop",
    description: "تطوير متجر بيع بالتجزئة وتطبيق جوال مصاحب لدار أزياء عبايات سعودية، مع واجهات تفاعلية وسرعة تصفح فائقة لتعزيز تحويل المبيعات.",
    tags: ["تطوير ويب", "تطبيق جوال", "تجربة مستخدم UI/UX"],
    features: ["تقسيط فوري عبر تمارا وتابي", "فلترة ذكية للمقاسات والموديلات", "ربط مباشر بنظام جرد المستودعات"]
  },
  {
    title: "محامص قهوة النخبة والتمور",
    category: "قهوة مختصة وتمور ملكية",
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=800&auto=format&fit=crop",
    description: "موقع تفاعلي لعرض وبيع أنواع البن الفاخر والتمور السعودية المغلفة بأسلوب ملكي، مع ميزة الاشتراكات الشهرية لشحن القهوة الطازجة للعملاء.",
    tags: ["تصميم مخصص", "اشتراكات دورية", "سيو متكامل SEO"],
    features: ["نظام اشتراكات شهرية متكررة", "حساب أوتوماتيكي لتكلفة الشحن المحلي", "واجهة إدارة مبيعات فورية"]
  }
];

export default function Portfolio() {
  return (
    <section id="portfolio" className="py-24 px-4 md:px-8 bg-surface-container-lowest/50 relative overflow-hidden">
      {/* Decorative blurs */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-16 space-y-4">
          <span className="inline-flex items-center gap-1.5 bg-primary/10 text-primary px-3 py-1.5 rounded-full text-xs font-semibold">
            <Award className="w-3.5 h-3.5" />
            <span>معرض أعمالنا ومشاريع النخبة</span>
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-on-surface">
            روائع من أعمالنا في تصميم وتطوير المتاجر
          </h2>
          <p className="text-on-surface-variant max-w-2xl mx-auto leading-relaxed">
            استكشف مجموعة من المتاجر الإلكترونية الراقية والهويات البصرية الفاخرة التي قمنا بتطويرها لعلامات تجارية متميزة في السوق السعودي.
          </p>
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {PROJECTS.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="glass-panel rounded-2xl overflow-hidden border border-white/5 hover:border-primary/30 transition-all duration-300 flex flex-col group h-full bg-[#16130b]/60 shadow-xl"
            >
              {/* Cover Image Container */}
              <div className="relative aspect-video overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-[#16130b] via-[#16130b]/20 to-transparent z-10 opacity-60 group-hover:opacity-20 transition-opacity duration-300" />
                <img
                  src={project.image}
                  alt={project.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <span className="absolute top-4 right-4 bg-[#16130b]/90 text-primary text-xs font-bold px-3 py-1.5 rounded-lg border border-white/10 z-20">
                  {project.category}
                </span>
              </div>

              {/* Card Body */}
              <div className="p-6 md:p-8 flex-grow flex flex-col justify-between text-right space-y-6">
                <div className="space-y-3">
                  <h3 className="text-xl font-bold text-on-surface group-hover:text-primary transition-colors duration-300">
                    {project.title}
                  </h3>
                  <p className="text-sm text-on-surface-variant leading-relaxed">
                    {project.description}
                  </p>

                  {/* Highlights checklist */}
                  <div className="pt-4 space-y-2 border-t border-white/5">
                    {project.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center justify-end gap-2 text-xs text-on-surface-variant">
                        <span>{feature}</span>
                        <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Tags block */}
                <div className="flex flex-wrap gap-2 justify-start pt-2">
                  {project.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] bg-primary/10 text-primary font-semibold px-2.5 py-1 rounded-md border border-primary/10"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Call to action at bottom */}
        <div className="text-center mt-16">
          <p className="text-sm text-on-surface-variant mb-4">
            هل ترغب في الحصول على متجر يحقق لعلامتك حضوراً ريادياً مماثلاً؟
          </p>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 bg-gold-gradient hover:bg-gold-gradient-hover text-[#1a1500] px-8 py-3.5 rounded-xl font-bold transition-all bg-glow-gold shadow-lg text-sm"
          >
            <span>احجز موعد استشارتك المجانية الآن</span>
          </a>
        </div>
      </div>
    </section>
  );
}
